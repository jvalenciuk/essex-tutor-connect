import Stripe from 'stripe';
import {db} from '../../../../lib/db';
import {identity,fail} from '../../../../lib/security';
export async function POST(){
 const who=await identity();if(who?.role!=='TUTOR')return fail('Tutor account required',403);
 if(!process.env.STRIPE_SECRET_KEY||!process.env.APP_URL)return fail('Stripe not configured',503);
 const profile=await db.tutorProfile.findUnique({where:{userId:who.id}});
 if(!profile||profile.verification!=='APPROVED')return fail('Administrator approval required',403);
 const stripe=new Stripe(process.env.STRIPE_SECRET_KEY);
 let account=profile.stripeAccountId;
 if(!account){const created=await stripe.accounts.create({type:'express',country:'CA',capabilities:{transfers:{requested:true}},metadata:{tutorId:profile.id}});account=created.id;await db.tutorProfile.update({where:{id:profile.id},data:{stripeAccountId:account}});}
 const url=new URL('/dashboard',process.env.APP_URL).toString();
 const link=await stripe.accountLinks.create({account,refresh_url:url+'?connect=retry',return_url:url+'?connect=return',type:'account_onboarding'});
 return Response.json({url:link.url});
}
